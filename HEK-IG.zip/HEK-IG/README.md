# HEK-IG
Hack instagram account with Bruteforce method !
# Description
Just my tools for hack instagram
<img src="https://github.com/saydog/HEK-IG/blob/master/VideoSnapshot_20191005_194504.jpg">
# Installations
```
$ pkg install python2
$ pip2 install colorama requests mechanize
$ pkg install openssh -y
$ pkg install git
$ git clone https://github.com/saydog/HEK-IG
$ cd HEK-IG
$ python2 dog.py
```

